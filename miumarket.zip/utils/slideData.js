const slidesData = [
    {
        name: '1',
        background: 'https://res.cloudinary.com/dfshhapcu/image/upload/v1695241529/1-background_zz0f6w.jpg',
        logo: 'https://res.cloudinary.com/dfshhapcu/image/upload/v1695241529/1-logo_uaswss.png',
    },
    {
        name: '2-2',
        background: 'https://res.cloudinary.com/dfshhapcu/image/upload/v1695241530/2-2-background_x3dqgv.jpg',
        logo: 'https://res.cloudinary.com/dfshhapcu/image/upload/v1695241529/2-2-logo_qv71hf.png',
    },
    {
        name: '3',
        background: 'https://res.cloudinary.com/dfshhapcu/image/upload/v1695241529/3-background_e1xlrr.jpg',
        logo: 'https://res.cloudinary.com/dfshhapcu/image/upload/v1695241529/3-logo_dqng2e.png',
    },
];

export default slidesData